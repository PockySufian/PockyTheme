import React, { useEffect } from 'react';
import PockyCommandMenu from './PockyCommandMenu';

const PockyThemeBoot: React.FC = () => {
    useEffect(() => {
        document.documentElement.dataset.pockytheme = 'true';
        document.body.classList.add('pockytheme-body');
        const handler = (e: KeyboardEvent) => {
            if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
                e.preventDefault();
                window.dispatchEvent(new Event('pocky:command'));
            }
        };
        window.addEventListener('keydown', handler);
        return () => {
            window.removeEventListener('keydown', handler);
            delete document.documentElement.dataset.pockytheme;
            document.body.classList.remove('pockytheme-body');
        };
    }, []);
    return <PockyCommandMenu />;
};
export default PockyThemeBoot;
