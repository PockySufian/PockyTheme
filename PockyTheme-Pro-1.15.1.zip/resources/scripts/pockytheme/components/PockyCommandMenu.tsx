import React, { useEffect, useMemo, useRef, useState } from 'react';

const items = [
    ['Dashboard', '/'],
    ['Servers', '/server'],
    ['Account', '/account'],
];

const PockyCommandMenu: React.FC = () => {
    const [open,setOpen]=useState(false);
    const [q,setQ]=useState('');
    const input=useRef<HTMLInputElement>(null);
    useEffect(()=>{const h=()=>setOpen(true);window.addEventListener('pocky:command',h);return()=>window.removeEventListener('pocky:command',h)},[]);
    useEffect(()=>{if(open)setTimeout(()=>input.current?.focus(),0);},[open]);
    const filtered=useMemo(()=>items.filter(x=>x[0].toLowerCase().includes(q.toLowerCase())),[q]);
    if(!open)return <button className="pocky-command-trigger" onClick={()=>setOpen(true)}>Search <kbd>Ctrl K</kbd></button>;
    return <div className="pocky-command-backdrop" onMouseDown={()=>setOpen(false)}>
        <div className="pocky-command" role="dialog" aria-modal="true" onMouseDown={e=>e.stopPropagation()}>
            <input ref={input} className="pocky-command-input" value={q} onChange={e=>setQ(e.target.value)} placeholder="Search your panel…" />
            <div className="pocky-command-list">{filtered.length ? filtered.map(x=><a className="pocky-command-item" key={x[1]} href={x[1]}>{x[0]}</a>) : <div className="pocky-command-empty">No results.</div>}</div>
            <div className="pocky-command-footer">Ctrl K to open · click outside to close</div>
        </div>
    </div>;
};
export default PockyCommandMenu;
