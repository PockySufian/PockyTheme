# PockyTheme Pro 1.0.0
Premium React/TypeScript visual integration for Pterodactyl 1.15.x.
Preserves Pterodactyl authentication, permissions, routes, API and WebSocket functionality.

Install:
chmod +x install.sh UNINSTALL.sh
./install.sh /var/www/pterodactyl
cd /var/www/pterodactyl
yarn install --frozen-lockfile
yarn tsc
yarn build:production
php artisan optimize:clear
systemctl restart nginx

Uninstall:
./UNINSTALL.sh /var/www/pterodactyl
