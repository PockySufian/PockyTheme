#!/usr/bin/env bash
set -euo pipefail
PANEL="${1:-/var/www/pterodactyl}"
INDEX="$PANEL/resources/scripts/index.tsx"
BACKUP="$(ls -1t "$INDEX".pocky-backup-* 2>/dev/null | head -n 1 || true)"
if [ -n "$BACKUP" ]; then
  cp "$BACKUP" "$INDEX"
else
  python3 - "$INDEX" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
s=s.replace("import './pockytheme/styles/pockytheme.css';\n","")
s=s.replace("import { PockyThemeBoot } from './pockytheme';\n","")
s=s.replace("""ReactDOM.render(
    <>
        <PockyThemeBoot />
        <App />
    </>,
    document.getElementById('app')
);""","ReactDOM.render(<App />, document.getElementById('app'));")
p.write_text(s)
PY
fi
rm -rf "$PANEL/resources/scripts/pockytheme"
echo "PockyTheme Pro removed. Rebuild the frontend."
