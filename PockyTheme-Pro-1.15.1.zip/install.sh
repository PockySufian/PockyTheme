#!/usr/bin/env bash
set -euo pipefail
PANEL="${1:-/var/www/pterodactyl}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INDEX="$PANEL/resources/scripts/index.tsx"
STAMP="$(date +%Y%m%d-%H%M%S)"
[ -d "$PANEL" ] || { echo "ERROR: Panel directory not found"; exit 1; }
[ -f "$PANEL/artisan" ] && [ -f "$PANEL/package.json" ] || { echo "ERROR: Not a Pterodactyl Panel"; exit 1; }
grep -q '"name": "pterodactyl/panel"' "$PANEL/composer.json" || { echo "ERROR: Not Pterodactyl"; exit 1; }
[ -f "$INDEX" ] || { echo "ERROR: React entry not found"; exit 1; }
mkdir -p "$PANEL/resources/scripts/pockytheme/components" "$PANEL/resources/scripts/pockytheme/styles"
cp "$INDEX" "$INDEX.pocky-backup-$STAMP"
cp "$HERE/resources/scripts/pockytheme/index.ts" "$PANEL/resources/scripts/pockytheme/index.ts"
cp "$HERE/resources/scripts/pockytheme/components/PockyThemeBoot.tsx" "$PANEL/resources/scripts/pockytheme/components/PockyThemeBoot.tsx"
cp "$HERE/resources/scripts/pockytheme/components/PockyCommandMenu.tsx" "$PANEL/resources/scripts/pockytheme/components/PockyCommandMenu.tsx"
cp "$HERE/resources/scripts/pockytheme/styles/pockytheme.css" "$PANEL/resources/scripts/pockytheme/styles/pockytheme.css"
python3 - "$INDEX" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
if "import './pockytheme/styles/pockytheme.css';" not in s:
    s=s.replace("import './i18n';","import './i18n';\nimport './pockytheme/styles/pockytheme.css';")
if "import { PockyThemeBoot } from './pockytheme';" not in s:
    s=s.replace("import App from '@/components/App';","import App from '@/components/App';\nimport { PockyThemeBoot } from './pockytheme';")
old="ReactDOM.render(<App />, document.getElementById('app'));"
new="ReactDOM.render(\n    <>\n        <PockyThemeBoot />\n        <App />\n    </>,\n    document.getElementById('app')\n);"
if old in s: s=s.replace(old,new)
elif "<PockyThemeBoot />" not in s: raise SystemExit("React entry format not recognized")
p.write_text(s)
PY
echo "PockyTheme Pro installed. Backup: $INDEX.pocky-backup-$STAMP"
