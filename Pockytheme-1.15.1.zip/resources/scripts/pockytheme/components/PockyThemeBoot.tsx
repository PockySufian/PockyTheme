import React, { useEffect } from 'react';
const PockyThemeBoot: React.FC = () => {
 useEffect(() => { document.documentElement.dataset.pockytheme='true'; document.body.classList.add('pockytheme-body');
 return () => document.body.classList.remove('pockytheme-body'); }, []);
 return null;
};
export default PockyThemeBoot;
