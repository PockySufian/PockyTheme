import React,{useEffect,useMemo,useState} from 'react';
import {Link} from 'react-router-dom';
const items=[{label:'Dashboard',path:'/'},{label:'Account',path:'/account'}];
const PockyCommandMenu:React.FC=()=>{const[open,setOpen]=useState(false),[q,setQ]=useState('');
useEffect(()=>{const f=(e:KeyboardEvent)=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();setOpen(v=>!v)}if(e.key==='Escape')setOpen(false)};addEventListener('keydown',f);return()=>removeEventListener('keydown',f)},[]);
const filtered=useMemo(()=>items.filter(x=>x.label.toLowerCase().includes(q.toLowerCase())),[q]);
if(!open)return <button className="pocky-command-trigger" onClick={()=>setOpen(true)} aria-label="Open command menu">Search <kbd>Ctrl K</kbd></button>;
return <div className="pocky-command-backdrop" onMouseDown={()=>setOpen(false)}><div className="pocky-command" role="dialog" aria-modal="true" onMouseDown={e=>e.stopPropagation()}>
<input autoFocus value={q} onChange={e=>setQ(e.target.value)} placeholder="Search the panel..." className="pocky-command-input"/>
<div className="pocky-command-list">{filtered.map(x=><Link key={x.path} to={x.path} className="pocky-command-item" onClick={()=>setOpen(false)}>{x.label}</Link>)}{!filtered.length&&<div className="pocky-command-empty">No matching pages.</div>}</div>
<div className="pocky-command-footer">Esc to close · Ctrl K to toggle</div></div></div>};
export default PockyCommandMenu;
