# Pockytheme 1.15.1
Premium dark/glass frontend overlay for Pterodactyl 1.15.1.

## Install
Upload/extract this folder under `/var/www/pterodactyl/`, then:
`cd /var/www/pterodactyl/Pockytheme-1.15.1 && bash install.sh /var/www/pterodactyl`
Then:
`cd /var/www/pterodactyl && yarn install --frozen-lockfile && yarn tsc && yarn build:production && php artisan optimize:clear`

## Important
This is intentionally a safe visual overlay. It keeps Pterodactyl's authentication, routes, API clients, permissions and WebSocket/console logic. It does not invent admin APIs or replace core Laravel functionality.
