#!/usr/bin/env bash
set -euo pipefail
PANEL="${1:-/var/www/pterodactyl}"; THEME="$PANEL/resources/scripts/pockytheme"; INDEX="$PANEL/resources/scripts/index.tsx"
test -f "$PANEL/artisan" && test -f "$PANEL/package.json" || { echo "Not a Pterodactyl Panel: $PANEL"; exit 1; }
mkdir -p "$THEME"; cp -a "$(dirname "$0")/resources/scripts/pockytheme/." "$THEME/"
if [ -f "$INDEX" ] && ! grep -q "pockytheme/styles/pockytheme.css" "$INDEX"; then cp "$INDEX" "$INDEX.pocky-backup"; printf "\nimport './pockytheme/styles/pockytheme.css';\n" >> "$INDEX"; fi
echo "Pockytheme installed. It is a safe visual overlay and does not replace Pterodactyl auth/API/permissions/WebSocket code."
