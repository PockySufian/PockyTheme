#!/usr/bin/env bash
set -euo pipefail
PANEL="${1:-/var/www/pterodactyl}"
sed -i "/pockytheme\/styles\/pockytheme.css/d" "$PANEL/resources/scripts/index.tsx" 2>/dev/null || true
rm -rf "$PANEL/resources/scripts/pockytheme"
echo "Removed Pockytheme overlay. Rebuild the frontend."
