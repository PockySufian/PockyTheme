# PockyTheme

Original premium Pterodactyl Panel 1.15.1 theme.

This project is an independent implementation inspired by the visual goals of modern
premium hosting panels. It does not contain Nebula source code, proprietary assets,
or Nebula branding.

## One-command VPS installation

    cd /var/www
    unzip -o PockyTheme-1.15.1.zip -d PockyTheme
    cd PockyTheme
    chmod +x all.cmd
    bash all.cmd /var/www/pterodactyl

The installer backs up the React entry point, installs PockyTheme assets, registers
the theme, builds the frontend, clears Laravel caches, and restarts nginx.

## Uninstall

    bash uninstall.cmd /var/www/pterodactyl

Then rebuild the frontend if required.
