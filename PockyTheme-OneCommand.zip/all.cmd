#!/usr/bin/env bash
set -Eeuo pipefail

# PockyTheme ONE-COMMAND installer
# Usage:
#   bash all.cmd
#   bash all.cmd /var/www/pterodactyl
#
# If this script is copied out of the repository, it clones the official
# PockyTheme repository and uses its latest package. If run from the cloned
# repository, it installs the local package.

PANEL="${1:-/var/www/pterodactyl}"
REPO="https://github.com/PockySufian/PockyTheme.git"
TMP="/tmp/pockytheme-install-$$"
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cleanup() { rm -rf "$TMP"; }
trap cleanup EXIT

echo "=============================================="
echo "           POCKYTHEME ONE-COMMAND"
echo "=============================================="
echo "Panel: $PANEL"

[ "$(id -u)" -eq 0 ] || { echo "ERROR: Run as root."; exit 1; }
[ -d "$PANEL" ] || { echo "ERROR: Panel directory not found: $PANEL"; exit 1; }
[ -f "$PANEL/artisan" ] || { echo "ERROR: Pterodactyl artisan not found."; exit 1; }
[ -f "$PANEL/composer.json" ] || { echo "ERROR: composer.json not found."; exit 1; }
[ -f "$PANEL/package.json" ] || { echo "ERROR: package.json not found."; exit 1; }
grep -q '"name": "pterodactyl/panel"' "$PANEL/composer.json" || {
    echo "ERROR: This is not detected as a Pterodactyl Panel."
    exit 1
}

echo "[1/8] Checking required commands..."
for c in git python3 unzip php yarn; do
    command -v "$c" >/dev/null 2>&1 || {
        echo "ERROR: Missing command: $c"
        echo "Install it first, then rerun this installer."
        exit 1
    }
done

echo "[2/8] Getting PockyTheme..."
if [ -f "$SELF_DIR/pockytheme.json" ] && [ -d "$SELF_DIR/resources" ]; then
    SRC="$SELF_DIR"
    echo "Using local PockyTheme package."
else
    rm -rf "$TMP"
    git clone --depth 1 "$REPO" "$TMP/repo"
    SRC="$TMP/repo"

    # Support repositories that publish a ZIP instead of loose theme files.
    if [ ! -f "$SRC/pockytheme.json" ] || [ ! -d "$SRC/resources" ]; then
        ZIP="$(find "$SRC" -maxdepth 2 -type f -iname '*pockytheme*.zip' | head -n1 || true)"
        if [ -z "$ZIP" ]; then
            echo "ERROR: Repository does not contain a usable PockyTheme package."
            exit 1
        fi
        mkdir -p "$TMP/extracted"
        unzip -oq "$ZIP" -d "$TMP/extracted"
        SRC="$(find "$TMP/extracted" -type f -name pockytheme.json -printf '%h\n' | head -n1)"
    fi
fi

[ -f "$SRC/pockytheme.json" ] || { echo "ERROR: PockyTheme manifest missing."; exit 1; }
[ -d "$SRC/resources/scripts/pockytheme" ] || {
    echo "ERROR: PockyTheme React files missing."
    exit 1
}

INDEX="$PANEL/resources/scripts/index.tsx"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$INDEX.pocky-backup-$STAMP"

echo "[3/8] Creating backup..."
cp "$INDEX" "$BACKUP"

echo "[4/8] Installing PockyTheme..."
mkdir -p "$PANEL/resources/scripts/pockytheme"
cp -R "$SRC/resources/scripts/pockytheme/." \
      "$PANEL/resources/scripts/pockytheme/"

if [ -f "$SRC/resources/scripts/pockytheme/assets/pockytheme.svg" ]; then
    mkdir -p "$PANEL/public/assets"
    cp "$SRC/resources/scripts/pockytheme/assets/pockytheme.svg" \
       "$PANEL/public/assets/pockytheme.svg"
fi

echo "[5/8] Registering React entry..."
python3 - "$INDEX" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()

css = "import './pockytheme/styles/pockytheme.css';"
boot = "import { PockyThemeBoot } from './pockytheme';"

if css not in s:
    marker = "import './i18n';"
    s = s.replace(marker, marker + "\n" + css) if marker in s else css + "\n" + s

if boot not in s:
    marker = "import App from '@/components/App';"
    s = s.replace(marker, marker + "\n" + boot) if marker in s else boot + "\n" + s

old = "ReactDOM.render(<App />, document.getElementById('app'));"
new = """ReactDOM.render(
    <>
        <PockyThemeBoot />
        <App />
    </>,
    document.getElementById('app')
);"""

if old in s:
    s = s.replace(old, new)
elif "<PockyThemeBoot />" not in s:
    raise SystemExit("Unsupported React entry format. Backup was created; no build performed.")

p.write_text(s)
PY

grep -q "PockyThemeBoot" "$INDEX" || { echo "ERROR: Registration failed."; exit 1; }
grep -q "pockytheme/styles/pockytheme.css" "$INDEX" || { echo "ERROR: CSS registration failed."; exit 1; }

echo "[6/8] Installing/building dependencies..."
cd "$PANEL"
yarn install --frozen-lockfile
yarn tsc
yarn build:production

echo "[7/8] Clearing Laravel cache..."
php artisan optimize:clear

echo "[8/8] Restarting services..."
chown -R www-data:www-data "$PANEL/resources/scripts/pockytheme" 2>/dev/null || true
systemctl restart nginx 2>/dev/null || true

echo
echo "=============================================="
echo "       POCKYTHEME INSTALLED SUCCESSFULLY"
echo "=============================================="
echo "Backup: $BACKUP"
echo
echo "Refresh the Pterodactyl panel."
echo "=============================================="
