# PockyTheme — One Command

The `all.cmd` installer can install from the package itself OR clone the
PockyTheme GitHub repository automatically.

## If you already downloaded this ZIP

```bash
cd /var/www
unzip -o PockyTheme-OneCommand.zip -d PockyTheme
cd PockyTheme
chmod +x all.cmd
bash all.cmd /var/www/pterodactyl
```

## GitHub clone mode

Once the repository contains this installer, you can also run:

```bash
cd /tmp
git clone --depth 1 https://github.com/PockySufian/PockyTheme.git
cd PockyTheme
chmod +x all.cmd
bash all.cmd /var/www/pterodactyl
```

The installer automatically:
- checks the target Pterodactyl panel
- clones the repository when not running from a package
- finds/extracts a PockyTheme ZIP when the repository publishes one
- backs up `resources/scripts/index.tsx`
- installs the React theme
- installs the Pocky logo
- runs `yarn install --frozen-lockfile`
- runs TypeScript checking
- builds production assets
- clears Laravel caches
- restarts nginx
