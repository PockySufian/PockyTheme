#!/usr/bin/env bash
set -Eeuo pipefail
PANEL="${1:-/var/www/pterodactyl}"
INDEX="$PANEL/resources/scripts/index.tsx"
BACKUP="$(ls -1t "$INDEX".pocky-backup-* 2>/dev/null | head -n1 || true)"

if [ -n "$BACKUP" ]; then
  cp "$BACKUP" "$INDEX"
  echo "Restored $BACKUP"
else
  echo "No PockyTheme backup found; refusing to alter index.tsx."
  exit 1
fi

rm -rf "$PANEL/resources/scripts/pockytheme"
echo "PockyTheme files removed."
echo "Run: cd $PANEL && yarn build:production && php artisan optimize:clear"
