import React, { useEffect, useMemo, useRef, useState } from 'react';

const pages = [
    ['Dashboard', '/'],
    ['Servers', '/server'],
    ['Account', '/account'],
];

const PockyCommandMenu: React.FC = () => {
    const [open, setOpen] = useState(false);
    const [q, setQ] = useState('');
    const input = useRef<HTMLInputElement>(null);

    useEffect(() => {
        const fn = () => setOpen(true);
        window.addEventListener('pocky:command', fn);
        return () => window.removeEventListener('pocky:command', fn);
    }, []);

    useEffect(() => {
        if (open) setTimeout(() => input.current?.focus(), 0);
        else setQ('');
    }, [open]);

    const results = useMemo(
        () => pages.filter(([name]) => name.toLowerCase().includes(q.toLowerCase())),
        [q]
    );

    if (!open) {
        return <button className="pocky-command-trigger" onClick={() => setOpen(true)}>
            <span>⌕ Search</span><kbd>Ctrl K</kbd>
        </button>;
    }

    return <div className="pocky-command-backdrop" onMouseDown={() => setOpen(false)}>
        <section className="pocky-command" onMouseDown={e => e.stopPropagation()} role="dialog" aria-modal="true">
            <header className="pocky-command-head">
                <img src="/assets/pockytheme.svg" alt="" />
                <strong>PockyTheme</strong>
                <span>Quick navigation</span>
            </header>
            <input ref={input} value={q} onChange={e => setQ(e.target.value)}
                   className="pocky-command-input" placeholder="Search panel..." />
            <div className="pocky-command-list">
                {results.map(([name, path]) => <a className="pocky-command-item" href={path} key={path}>{name}</a>)}
                {!results.length && <div className="pocky-command-empty">No results.</div>}
            </div>
            <footer>Ctrl K · ESC / click outside</footer>
        </section>
    </div>;
};

export default PockyCommandMenu;
