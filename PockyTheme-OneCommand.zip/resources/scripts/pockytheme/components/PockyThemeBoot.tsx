import React, { useEffect } from 'react';
import PockyCommandMenu from './PockyCommandMenu';

const PockyThemeBoot: React.FC = () => {
    useEffect(() => {
        const root = document.documentElement;
        root.dataset.pockytheme = 'true';
        document.body.classList.add('pockytheme-body');

        const onKey = (e: KeyboardEvent) => {
            if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
                e.preventDefault();
                window.dispatchEvent(new Event('pocky:command'));
            }
        };
        window.addEventListener('keydown', onKey);
        return () => {
            window.removeEventListener('keydown', onKey);
            delete root.dataset.pockytheme;
            document.body.classList.remove('pockytheme-body');
        };
    }, []);

    return <PockyCommandMenu />;
};

export default PockyThemeBoot;
