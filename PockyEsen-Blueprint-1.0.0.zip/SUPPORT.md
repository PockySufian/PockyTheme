# Support

PockyEsen is distributed as an original commercial product by SufianEsen.

## Please include

When reporting an issue, provide:

- PockyEsen version
- Pterodactyl version
- Blueprint version
- PHP version
- Node.js version
- browser and browser version
- whether the issue occurs in admin, client panel, or both
- a screenshot and browser console error if relevant

Do not post passwords, API keys, session cookies, Wings tokens or other secrets.

## Compatibility issues

If the panel was upgraded immediately before the problem appeared, reproduce the issue on a staging panel before changing production files.

PockyEsen does not provide or require a custom backend command channel.
