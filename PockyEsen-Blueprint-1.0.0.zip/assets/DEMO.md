# Demo assets

The supplied reference images are intentionally not redistributed in this package; they were used only as the visual design reference for this implementation.

The original PockyEsen icon is included as `pockyesen-icon.svg`.

For commercial release, capture fresh screenshots from a real Pterodactyl 1.14.x + Blueprint beta-2026-06 staging panel after installation. Do not use screenshots from third-party themes.
