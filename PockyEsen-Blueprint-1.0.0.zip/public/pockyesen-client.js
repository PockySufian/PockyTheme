(function () {
    'use strict';

    const KEY = 'pockyesen-settings';
    const presets = {
        'Pocky Pink':    { primary:'#ff2f9d', secondary:'#9d4edd' },
        'Pocky Purple':  { primary:'#b66cff', secondary:'#6f42c1' },
        'Pocky Ocean':   { primary:'#31c7ff', secondary:'#6a5cff' },
        'Pocky Sunset':  { primary:'#ff6b6b', secondary:'#ff9f43' },
        'Pocky Green':   { primary:'#36e08f', secondary:'#16a085' },
        'Pocky Midnight':{ primary:'#d7b8ff', secondary:'#6f5bd3' }
    };
    const defaults = {
        preset:'Pocky Pink', primary:'#ff2f9d', secondary:'#9d4edd',
        radius:14, glow:0.65, animation:1, density:'comfortable', font:'normal', mode:'dark',
        background:'gradient', backgroundColor:'#07070b', cards:'glass', sidebar:'default',
        border:0.20, shadow:0.38
    };
    let state = defaults;
    try { state = Object.assign({}, defaults, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (_) {}

    function apply() {
        const r = document.documentElement;
        r.style.setProperty('--pocky-primary', state.primary);
        r.style.setProperty('--pocky-secondary', state.secondary);
        r.style.setProperty('--pocky-radius', `${Math.max(4, Math.min(24, Number(state.radius) || 14))}px`);
        r.style.setProperty('--pocky-bg-custom', state.backgroundColor || '#07070b');
        r.style.setProperty('--pocky-card-alpha', String(state.cards === 'solid' ? .94 : state.cards === 'transparent' ? .52 : .78));
        r.style.setProperty('--pocky-border-alpha', String(state.border));
        r.style.setProperty('--pocky-shadow-alpha', String(state.shadow));
        r.style.setProperty('--pocky-glow-strength', String(state.glow));
        r.style.setProperty('--pocky-animation-strength', String(state.animation));
        r.dataset.pockyMode = state.mode === 'light' ? 'light' : 'dark';
        r.dataset.pockyFont = state.font || 'normal';
        r.dataset.pockyDensity = state.density || 'comfortable';
        r.dataset.pockyBackground = state.background || 'gradient';
        r.dataset.pockyCards = state.cards || 'glass';
        r.dataset.pockySidebar = state.sidebar || 'default';
        document.body.classList.toggle('pocky-no-glow', Number(state.glow) <= 0.02);
        localStorage.setItem(KEY, JSON.stringify(state));
    }
    function save() { apply(); renderState(); }

    function renderState() {
        document.querySelectorAll('[data-pocky-preset]').forEach(function (el) {
            el.setAttribute('aria-pressed', el.dataset.pockyPreset === state.preset ? 'true' : 'false');
        });
        const radius = document.querySelector('[data-pocky-radius]');
        const glow = document.querySelector('[data-pocky-glow]');
        const animation = document.querySelector('[data-pocky-animation]');
        const font = document.querySelector('[data-pocky-font]');
        const density = document.querySelector('[data-pocky-density]');
        const mode = document.querySelector('[data-pocky-mode]');
        const background = document.querySelector('[data-pocky-background]');
        const backgroundColor = document.querySelector('[data-pocky-background-color]');
        const cards = document.querySelector('[data-pocky-cards]');
        const border = document.querySelector('[data-pocky-border]');
        const shadow = document.querySelector('[data-pocky-shadow]');
        const sidebar = document.querySelector('[data-pocky-sidebar]');
        if (radius) radius.value = state.radius;
        if (glow) glow.value = state.glow;
        if (animation) animation.value = state.animation;
        if (font) font.value = state.font || 'normal';
        if (density) density.value = state.density || 'comfortable';
        if (mode) mode.value = state.mode || 'dark';
        if (background) background.value = state.background || 'gradient';
        if (backgroundColor) backgroundColor.value = state.backgroundColor || '#07070b';
        if (cards) cards.value = state.cards || 'glass';
        if (border) border.value = state.border ?? .20;
        if (shadow) shadow.value = state.shadow ?? .38;
        if (sidebar) sidebar.value = state.sidebar || 'default';
    }

    function createUI() {
        if (document.querySelector('.pocky-theme-toggle')) return;

        const toggle = document.createElement('button');
        toggle.type = 'button';
        toggle.className = 'pocky-theme-toggle';
        toggle.textContent = '✦';
        toggle.title = 'PockyEsen settings';
        toggle.setAttribute('aria-label', 'Open PockyEsen settings');

        const drawer = document.createElement('aside');
        drawer.className = 'pocky-theme-drawer';
        drawer.hidden = true;
        drawer.setAttribute('aria-label', 'PockyEsen customization');
        drawer.innerHTML = `
            <h3>PockyEsen</h3>
            <p>Personal UI preferences. No Pterodactyl functionality is changed.</p>
            <div class="pocky-theme-grid">
                ${Object.keys(presets).map(function(name) {
                    const c = presets[name];
                    return '<button type="button" data-pocky-preset="' + name.replace(/"/g,'&quot;') + '"><span class="pocky-theme-swatch" style="color:'+c.primary+';background:'+c.primary+'"></span>'+name+'</button>';
                }).join('')}
            </div>
            <div class="pocky-theme-controls">
                <label>Custom primary <input data-pocky-primary type="color" value="${state.primary}"></label>
                <label>Custom secondary <input data-pocky-secondary type="color" value="${state.secondary}"></label>
                <label>Border radius <input data-pocky-radius type="range" min="4" max="24" step="1" value="${state.radius}"></label>
                <label>Glow intensity <input data-pocky-glow type="range" min="0" max="1" step=".05" value="${state.glow}"></label>
                <label>Animation intensity <input data-pocky-animation type="range" min="0" max="1" step=".05" value="${state.animation}"></label>
                <label>Font size
                    <select data-pocky-font>
                        <option value="small">Small</option>
                        <option value="normal">Normal</option>
                        <option value="large">Large</option>
                    </select>
                </label>
                <label>Layout
                    <select data-pocky-density>
                        <option value="compact">Compact</option>
                        <option value="comfortable">Comfortable</option>
                    </select>
                </label>
                <label>Mode
                    <select data-pocky-mode>
                        <option value="dark">Dark</option>
                        <option value="light">Light</option>
                    </select>
                </label>
                <label>Background
                    <select data-pocky-background>
                        <option value="gradient">Gradient</option>
                        <option value="solid">Solid</option>
                    </select>
                </label>
                <label>Background color <input data-pocky-background-color type="color" value="${state.backgroundColor}"></label>
                <label>Card transparency
                    <select data-pocky-cards>
                        <option value="glass">Glass</option>
                        <option value="transparent">More transparent</option>
                        <option value="solid">Solid</option>
                    </select>
                </label>
                <label>Border intensity <input data-pocky-border type="range" min="0" max=".5" step=".01" value="${state.border}"></label>
                <label>Shadow intensity <input data-pocky-shadow type="range" min="0" max=".8" step=".05" value="${state.shadow}"></label>
                <label>Sidebar width
                    <select data-pocky-sidebar>
                        <option value="default">Default</option>
                        <option value="wide">Wide</option>
                    </select>
                </label>
            </div>
        `;

        document.body.appendChild(toggle);
        document.body.appendChild(drawer);

        toggle.addEventListener('click', function () {
            drawer.hidden = !drawer.hidden;
            toggle.setAttribute('aria-expanded', drawer.hidden ? 'false' : 'true');
        });
        drawer.addEventListener('click', function (event) {
            const preset = event.target.closest('[data-pocky-preset]');
            if (preset) {
                const name = preset.dataset.pockyPreset;
                const p = presets[name];
                state = Object.assign({}, state, {preset:name, primary:p.primary, secondary:p.secondary});
                save();
                return;
            }
            if (event.target.matches('[data-pocky-primary]')) {
                state = Object.assign({}, state, {preset:'Custom Theme', primary:event.target.value});
                save();
            }
            if (event.target.matches('[data-pocky-secondary]')) {
                state = Object.assign({}, state, {preset:'Custom Theme', secondary:event.target.value});
                save();
            }
            if (event.target.matches('[data-pocky-radius]')) {
                state = Object.assign({}, state, {radius:event.target.value});
                save();
            }
            if (event.target.matches('[data-pocky-glow]')) {
                state = Object.assign({}, state, {glow:event.target.value});
                save();
            }
            if (event.target.matches('[data-pocky-animation]')) {
                state = Object.assign({}, state, {animation:event.target.value});
                save();
            }
            if (event.target.matches('[data-pocky-font]')) {
                state = Object.assign({}, state, {font:event.target.value});
                save();
            }
            if (event.target.matches('[data-pocky-density]')) {
                state = Object.assign({}, state, {density:event.target.value});
                save();
            }
            if (event.target.matches('[data-pocky-mode]')) {
                state = Object.assign({}, state, {mode:event.target.value});
                save();
            }
            if (event.target.matches('[data-pocky-background]')) {
                state = Object.assign({}, state, {background:event.target.value});
                save();
            }
            if (event.target.matches('[data-pocky-background-color]')) {
                state = Object.assign({}, state, {backgroundColor:event.target.value});
                save();
            }
            if (event.target.matches('[data-pocky-cards]')) {
                state = Object.assign({}, state, {cards:event.target.value});
                save();
            }
            if (event.target.matches('[data-pocky-border]')) {
                state = Object.assign({}, state, {border:event.target.value});
                save();
            }
            if (event.target.matches('[data-pocky-shadow]')) {
                state = Object.assign({}, state, {shadow:event.target.value});
                save();
            }
            if (event.target.matches('[data-pocky-sidebar]')) {
                state = Object.assign({}, state, {sidebar:event.target.value});
                save();
            }
        });
        renderState();
    }

    function boot() {
        apply();
        createUI();
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
    else boot();
})();
