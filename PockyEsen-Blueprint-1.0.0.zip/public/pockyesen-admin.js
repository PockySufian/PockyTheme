(function () {
    'use strict';
    const KEY = 'pockyesen-admin-settings';
    const defaults = { glow: true, radius: 14, density: 1 };
    let settings = defaults;
    try { settings = Object.assign({}, defaults, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (_) {}

    const root = document.documentElement;
    root.style.setProperty('--pocky-radius', `${Number(settings.radius) || 14}px`);
    if (!settings.glow) document.body.classList.add('pocky-no-glow');

    if (!document.querySelector('.pocky-admin-theme-button')) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'pocky-admin-theme-button';
        button.title = 'PockyEsen quick settings';
        button.setAttribute('aria-label', 'PockyEsen quick settings');
        button.textContent = '✦';
        button.addEventListener('click', function () {
            const glow = !document.body.classList.contains('pocky-no-glow');
            const next = Object.assign({}, settings, { glow: !glow });
            settings = next;
            document.body.classList.toggle('pocky-no-glow', !next.glow);
            localStorage.setItem(KEY, JSON.stringify(next));
        });
        document.body.appendChild(button);
    }
})();
