# Changelog

## 1.0.0 — 2026-08-16

### Added

- Original PockyEsen visual system.
- Admin and client neon-glass styling.
- Responsive cards, tables, forms, navigation and dialogs.
- Pocky Pink, Purple, Ocean, Sunset, Green and Midnight presets.
- Custom primary/secondary color controls.
- Persistent local-browser theme settings.
- Glow intensity control.
- Border-radius control.
- Animation intensity control.
- Font-size, compact/comfortable density and a limited light-mode option.
- Reduced-motion support.
- Original PockyEsen icon.
- Commercial documentation and compatibility declaration.

### Safety

- No Pterodactyl backend logic changed.
- No database migrations.
- No API or route modifications.
- No arbitrary command execution.
- No credential collection.
- No remote scripts.
- No third-party proprietary theme source.
