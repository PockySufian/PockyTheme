# Validation

Recommended release checks:

- YAML parse for `conf.yml`
- JavaScript syntax check for `dashboard/wrapper.blade.php` and `admin/wrapper.blade.php` extracted scripts
- shell syntax check for any Blueprint scripts (none are included)
- ZIP integrity check
- grep for prohibited third-party branding
- verify all `conf.yml` bindings exist
