
<div class="pocky-extension-shell">
    <div class="pocky-extension-hero">
        <div class="pocky-brand">
            <img src="{webroot/public}/pockyesen-icon.svg" alt="PockyEsen icon">
            <div>
                <div class="pocky-kicker">ORIGINAL PTERODACTYL UI LAYER</div>
                <h1>PockyEsen</h1>
                <p>Premium neon-glass interface by SufianEsen.</p>
            </div>
        </div>
        <span class="pocky-version">v1.0.0</span>
    </div>

    <div class="pocky-admin-grid">
        <section class="pocky-panel-card">
            <h2>Theme Presets</h2>
            <p>Client-side customization is stored per browser and does not change Pterodactyl data.</p>
            <div class="pocky-preset-list">
                <span>Pocky Pink</span><span>Pocky Purple</span><span>Pocky Ocean</span>
                <span>Pocky Sunset</span><span>Pocky Green</span><span>Pocky Midnight</span>
            </div>
        </section>

        <section class="pocky-panel-card">
            <h2>Compatibility</h2>
            <dl>
                <div><dt>Pterodactyl</dt><dd>1.14.x</dd></div>
                <div><dt>Blueprint</dt><dd>beta-2026-06</dd></div>
                <div><dt>PHP</dt><dd>8.2+</dd></div>
                <div><dt>Node.js</dt><dd>22+</dd></div>
            </dl>
        </section>

        <section class="pocky-panel-card pocky-wide">
            <h2>Non-invasive by design</h2>
            <ul>
                <li>No backend routes or controllers are replaced.</li>
                <li>No database migrations are included.</li>
                <li>No authentication or permission logic is modified.</li>
                <li>No Wings/API/server-management behavior is changed.</li>
                <li>No arbitrary command execution or credential collection.</li>
            </ul>
        </section>
    </div>
</div>

<style>
.pocky-extension-shell{max-width:1120px;margin:24px auto;color:#f8f5fa}
.pocky-extension-hero,.pocky-panel-card{background:rgba(16,12,22,.82);border:1px solid rgba(255,47,157,.22);border-radius:16px;box-shadow:0 18px 55px rgba(0,0,0,.35),0 0 30px rgba(255,47,157,.10);backdrop-filter:blur(18px)}
.pocky-extension-hero{padding:24px;display:flex;justify-content:space-between;align-items:center;gap:18px}
.pocky-brand{display:flex;align-items:center;gap:14px}.pocky-brand h1{margin:2px 0;font-size:30px}.pocky-brand p{margin:0;color:#a69bab}
.pocky-kicker{font-size:10px;letter-spacing:.14em;color:#ff72bd;font-weight:700}.pocky-version{padding:7px 11px;border-radius:999px;background:rgba(255,47,157,.10);color:#ff72bd}
.pocky-admin-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px}.pocky-panel-card{padding:20px}.pocky-panel-card h2{margin:0 0 7px;font-size:17px}.pocky-panel-card p{color:#a69bab}
.pocky-wide{grid-column:1/-1}.pocky-preset-list{display:flex;flex-wrap:wrap;gap:8px}.pocky-preset-list span{padding:8px 10px;border:1px solid rgba(255,255,255,.08);border-radius:10px;background:rgba(255,255,255,.03)}
.pocky-panel-card dl{margin:0}.pocky-panel-card dl div{display:flex;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,.06);padding:8px 0}.pocky-panel-card dt{color:#a69bab}.pocky-panel-card dd{margin:0}
@media(max-width:720px){.pocky-admin-grid{grid-template-columns:1fr}.pocky-wide{grid-column:auto}.pocky-extension-hero{align-items:flex-start;flex-direction:column}}
</style>
