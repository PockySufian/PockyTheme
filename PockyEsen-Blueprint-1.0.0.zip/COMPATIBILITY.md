# Compatibility

## Release target

| Component | Supported target |
|---|---|
| Pterodactyl Panel | 1.14.x |
| Blueprint | beta-2026-06 |
| PHP | 8.2+ |
| Node.js | 22+ |
| Wings | unchanged; use the version required by your Pterodactyl installation |

## Why this target

Pterodactyl 1.12 raised the frontend build requirement to Node.js 22, and current Blueprint releases use Node.js 22 or later. Blueprint beta-2026-06 specifically notes compatibility work for the newer Pterodactyl line.

## Compatibility policy

PockyEsen is a CSS/wrapper-based visual extension and intentionally avoids patching Pterodactyl backend files. This reduces conflict risk, but it does not make the theme universally compatible.

Before upgrading Pterodactyl or Blueprint:

1. take a backup/snapshot of the panel;
2. review the PockyEsen changelog;
3. test the extension on a staging panel;
4. verify admin and client navigation;
5. verify console, file manager, database and schedule actions.

If a future Pterodactyl release changes class names or component markup, visual coverage may need an update even though backend functionality remains untouched.
