# PockyEsen

**PockyEsen** is an original, production-oriented visual theme layer for the Pterodactyl Panel by **SufianEsen**.

It is designed around the supplied PockyEsen visual references: near-black surfaces, neon pink/purple accents, glass panels, restrained status colors, rounded cards, and responsive layouts.

## What it changes

PockyEsen changes presentation only:

- global admin-panel visual styling
- client-panel visual styling
- authentication-page styling through the existing panel surfaces
- responsive cards, forms, tables, navigation, buttons, dialogs and status treatments
- local per-browser theme customization
- glow controls, accent presets, radius, glow and animation intensity
- original PockyEsen extension admin page and icon

## What it does not change

PockyEsen does **not** change:

- Pterodactyl routes or controllers
- database schema or migrations
- authentication or permissions
- Wings communication
- API endpoints or API semantics
- server lifecycle or management logic
- file-manager operations
- Git execution
- existing extensions' backend behavior

No custom database is required.

## Originality

This package was implemented from scratch from the visual reference supplied for this project. It does not contain proprietary source or branding from other commercial themes.

## Package

- `pockyesen.blueprint` — installable Blueprint extension
- `pockyesen-source.zip` — complete source archive
