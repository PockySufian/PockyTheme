# Architecture

## Admin

- `admin/admin.css`: global visual layer for Pterodactyl's admin interface.
- `admin/wrapper.blade.php`: tiny local preference toggle.
- `admin/view.blade.php`: extension information/customization page.

## Client

- `dashboard/dashboard.css`: global visual layer for the React client bundle.
- `dashboard/wrapper.blade.php`: local browser customizer.

## Assets

- `assets/pockyesen-icon.svg`: original extension icon.

## Persistence

Theme customization is browser-local and uses `localStorage`. This avoids adding database tables or altering Pterodactyl's data model.

## Conflict strategy

Selectors are intentionally based on common Pterodactyl/Tailwind/admin UI patterns and avoid deleting or replacing existing DOM nodes. The extension does not own server-management controls.

- `public/pockyesen-admin.js`: tiny local admin preference controller.
- `public/pockyesen-client.js`: client-side theme customizer and local persistence.
- `public/pockyesen-icon.svg`: public copy used by the extension admin view.
