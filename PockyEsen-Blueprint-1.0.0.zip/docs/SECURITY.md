# Security Notes

PockyEsen is a visual extension.

It does not:

- execute user-supplied shell commands;
- create administrator accounts;
- collect credentials;
- proxy API credentials;
- add API endpoints;
- change Pterodactyl permissions;
- change Wings communication;
- modify server files;
- execute Git commands.

The theme customizer stores presentation preferences in browser `localStorage`. No credentials are stored there.

The extension uses Blueprint's `admin.css`, `admin.wrapper`, `dashboard.css` and `dashboard.wrapper` bindings rather than patching Pterodactyl core source files.
