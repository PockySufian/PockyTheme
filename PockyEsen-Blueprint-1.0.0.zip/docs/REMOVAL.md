# Removal

From the Pterodactyl directory, run:

`blueprint -remove pockyesen`

Then reload the panel.

PockyEsen contains no database migrations and does not intentionally alter Pterodactyl core backend files, so removal is designed to be handled by Blueprint.

If you previously used a custom browser cache or local theme settings, they are stored under the browser's local storage and can be cleared from that browser; this is not panel data.
