# Release validation

Validated during packaging on 2026-08-16:

- `conf.yml` parsed successfully as YAML.
- All paths referenced by `conf.yml` exist.
- `pockyesen-admin.js` passed `node --check`.
- `pockyesen-client.js` passed `node --check`.
- Admin CSS brace balance: valid.
- Dashboard CSS brace balance: valid.
- No Blueprint install/update/remove scripts are included.
- No database migrations are included.
- No custom application/client/web routes are included.
- No shell execution primitives are present in source.
- No prohibited third-party theme names/branding are present in package text.
- Blueprint package ZIP integrity checked after creation.
- Source ZIP integrity checked after creation.

A real production release still requires staging-panel browser testing against the declared Pterodactyl/Blueprint versions before customer distribution.
