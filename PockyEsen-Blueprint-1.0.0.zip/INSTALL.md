# PockyEsen Installation

## Supported baseline

This release targets:

- Pterodactyl Panel: **1.14.x**
- Blueprint: **beta-2026-06**
- PHP: **8.2+** as required by the current Pterodactyl 1.x line
- Node.js: **22+** for the current Blueprint/Pterodactyl asset toolchain

Compatibility is intentionally narrow. Do not treat this package as universally compatible with future or older panel releases.

## Prerequisites

Install and configure Blueprint first.

The Pterodactyl webserver directory is normally:

`/var/www/pterodactyl`

## Install

1. Upload `pockyesen.blueprint` to:

`/var/www/pterodactyl/`

2. Enter the panel directory:

`cd /var/www/pterodactyl`

3. Install the extension:

`blueprint -install pockyesen`

Blueprint may rebuild the dashboard when the extension declares a frontend stylesheet.

4. If Blueprint reports that an asset rebuild is required, allow it to complete. Do not manually edit Pterodactyl source files.

5. Open the panel and verify the admin and client interfaces.

## Caches

PockyEsen does not require manual Laravel cache clearing as part of normal installation. If your Blueprint/Pterodactyl installation explicitly asks for cache clearing, follow the command it reports.

## Docker

For Blueprint Docker installations, place the extension in the directory configured by Blueprint Docker (currently documented as `/srv/pterodactyl/extensions`) rather than assuming `/var/www/pterodactyl`.

## First verification

- Sign in as an administrator.
- Open several admin list/detail pages.
- Sign in as a normal client.
- Open the server list, console, files, databases, schedules and account pages.
- Confirm that existing actions still behave as before.
